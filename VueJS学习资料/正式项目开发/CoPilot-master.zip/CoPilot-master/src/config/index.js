export default {
  serverURI: '',
  fixedLayout: false,
  hideLogoOnMobile: false
}
