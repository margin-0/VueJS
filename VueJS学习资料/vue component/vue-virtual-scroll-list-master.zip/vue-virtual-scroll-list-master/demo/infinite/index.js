import Vue from 'vue';
import InfiniteDemo from './infinite.vue';

new Vue({
	el: '#app',
	template: '<InfiniteDemo />',
	components: { InfiniteDemo }
});
