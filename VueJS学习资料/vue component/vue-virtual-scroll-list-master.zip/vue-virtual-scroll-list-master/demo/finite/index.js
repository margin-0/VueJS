import Vue from 'vue';
import FiniteDemo from './finite.vue';

new Vue({
	el: '#app',
	template: '<FiniteDemo />',
	components: { FiniteDemo }
});
